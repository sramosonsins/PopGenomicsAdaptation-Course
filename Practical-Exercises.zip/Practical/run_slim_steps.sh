## declare an array variable
declare -a slim_filenames=("slim_template-SNMR0.slim" "slim_template-SNMRh.slim" "slim_template-SSR0.slim" "slim_template-SSRh.slim" "slim_template-PSL.slim" "slim_template-PSM.slim" "slim_template-PSH.slim" "slim_template-SNM-EXP.slim" "slim_template-SNM-RED.slim" "slim_template-DELF.slim" "slim_template-DELG.slim" "slim_template-DELF-EXP.slim" "slim_template-PSL-DELF.slim" "slim_template-PSM-DELF.slim" "slim_template-PSH-DELF.slim")

## RUN SLIM
#for n in "${slim_filenames[@]}"
#do
#   slim -t -m $n > ${n}.out &
#done

##CUT TO MS FORMAT
for n in "${slim_filenames[@]}"
do
   sed '1,/Starting run/d'< ${n}.out > ${n}.out.ms
done

##RUN MSTATSPOP
for n in "${slim_filenames[@]}"
do
   ./mstatspop -f ms -i ${n}.out.ms -o 0 -N 2 25 5 -G 1 -l 30000 -r 1 -n name_scaffold.txt -m mask_neutral.txt > ${n}.out.ms.neutral_statistics.txt
   ./mstatspop -f ms -i ${n}.out.ms -o 0 -N 2 25 5 -G 1 -l 30000 -r 1 -n name_scaffold.txt -m mask_functional.txt > ${n}.out.ms.functional_statistics.txt
done

##MAKE TABLE asymptotic-MK
rm freq_col.txt
touch freq_col.txt
for i in `seq 1 24`;   do     answer=$(echo "scale=2; $i /25;" | bc);     echo "$answer" >> freq_col.txt;   done #create a column with frequencies

for n in "${slim_filenames[@]}"
do
   grep 'Divergence\[0' ${n}.out.ms.functional_statistics.txt | tr '\t' ' ' | cut -d ' ' -f18 | sed '$d' > ${n}.out.ms.functional_divergence.txt #functional divergence
   grep 'Divergence\[0' ${n}.out.ms.neutral_statistics.txt | tr '\t' ' ' | cut -d ' ' -f18 | sed '$d' > ${n}.out.ms.neutral_divergence.txt #neutral divergence
   grep 'Theta(' ${n}.out.ms.functional_statistics.txt | tr '\t' ' ' | cut -d ' ' -f4,6,8,10 > ${n}.out.ms.functional_variability.txt #functional variability
   grep 'Theta(' ${n}.out.ms.neutral_statistics.txt | tr '\t' ' ' | cut -d ' ' -f4,6,8,10 > ${n}.out.ms.neutral_variability.txt #neutral variability
   grep 'fr\[0,' ${n}.out.ms.functional_statistics.txt | tr '\t' '\n' | cut -d ' ' -f2 > ${n}.out.ms.functional_statistics.txt.SFS.txt #create a column with functional SFS.
   grep 'fr\[0,' ${n}.out.ms.neutral_statistics.txt | tr '\t' '\n' | cut -d ' ' -f2 > ${n}.out.ms.neutral_statistics.txt.SFS.txt #create a column with neutral SFS.
   paste freq_col.txt ${n}.out.ms.functional_statistics.txt.SFS.txt ${n}.out.ms.neutral_statistics.txt.SFS.txt > ${n}.cols.txt #join the frequencies and the SFS for functional and neutral.
   perl -ane 'print if $F[2]' ${n}.cols.txt > ${n}.cols_.txt #eliminate rows where syn is zero 
   echo -e "freq\tsfs_funct\tsfs_neutral" > ${n}.SFS.table.txt #make a header.
   cat  ${n}.cols_.txt > ${n}.SFS.table_.txt #join header with SFS columns.
   sed '$d' ${n}.SFS.table_.txt > ${n}.SFS.table.txt
done

##RUN asymptotic-MK
for n in "${slim_filenames[@]}"
do
   div=$(cat ${n}.out.ms.functional_divergence.txt)
   div0=$(cat ${n}.out.ms.neutral_divergence.txt) 
   curl -F"d=${div}" -F"d0=${div0}" -F"xlow=0.05" -F"xhigh=0.95" -F"datafile=@${n}.SFS.table.txt" -o "${n}.asymptotic-MK_full.html" http://benhaller.com/cgi-bin/R/asymptoticMK_run.html
   #curl -F"d=${div}" -F"d0=${div0}" -F"xlow=0.05" -F"xhigh=0.95" -F"datafile=@${n}.SFS.table.txt" -F"reply=table" -o "${n}.asymptotic-MK_table.txt" http://benhaller.com/cgi-bin/R/asymptoticMK_run.html
done
